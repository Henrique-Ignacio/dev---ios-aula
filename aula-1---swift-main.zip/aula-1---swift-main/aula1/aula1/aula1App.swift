//
//  aula1App.swift
//  aula1
//
//  Created by COTEMIG on 11/03/25.
//

import SwiftUI

@main
struct aula1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
